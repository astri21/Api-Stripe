<form action="charge.php" method="post">
  <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
          data-key="pk_test_tndX9Fma5CRDCEBormh26ABr"
          data-description="Access for a year"
          data-amount="5000"
          data-locale="auto"></script>
</form>